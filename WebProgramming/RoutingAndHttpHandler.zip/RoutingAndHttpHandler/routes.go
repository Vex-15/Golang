package main

import "net/http"

func (app *Application) routes() http.Handler {
	mux := http.NewServeMux()
	mux.Handle("/public", http.StripPrefix("/public/", http.FileServer(http.Dir(app.publicPath))))
	mux.HandleFunc("/", app.home)
	mux.HandleFunc("/about", app.about)
	mux.HandleFunc("/contact", app.contact)
	return mux
}
